<?php

$con = mysqli_connect('localhost' , 'root' , '' , 'nmec');

if(!$con)

    die('Database Connection Error');

?>