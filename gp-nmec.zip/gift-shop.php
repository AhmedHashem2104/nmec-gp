<?php
require('./layouts/header.php');
require('./layouts/nav.php');
?>
<iframe src="https://my.matterport.com/show/?m=coCTY6By9oF" style="margin-top:50px;margin-bottom:30px;width:85%;height:550px;" allowfullscreen></iframe>

<div style="display:flex;justify-content:center;align-items:center;">
<a href="index.php"><button class="btn btn-primary" style="margin-top:20px;margin-bottom:20px;width:200px;font-size:25px;">Go Home</button></a>

</div>

<?php
require('./layouts/footer.php');
?>